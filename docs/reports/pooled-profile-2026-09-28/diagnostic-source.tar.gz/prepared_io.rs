//! Acknowledged reset and readiness operations for retained endpoints.
use super::native_netlink::{CREATE, NESTED, NativeSocket, REQUEST, attr, attrs};
use std::fs::File;
use std::io;
use std::net::Ipv4Addr;
use std::os::fd::AsRawFd;

pub(super) struct EndpointIo {
    pub route: NativeSocket,
    conntrack: NativeSocket,
}

impl EndpointIo {
    pub fn open(namespace: Option<&File>) -> io::Result<Self> {
        let original = File::open("/proc/thread-self/ns/net")?;
        if let Some(namespace) = namespace
            && unsafe { libc::setns(namespace.as_raw_fd(), libc::CLONE_NEWNET) } != 0
        {
            return Err(io::Error::last_os_error());
        }
        let result = (|| {
            Ok(Self {
                route: NativeSocket::new(libc::NETLINK_ROUTE as _)?,
                conntrack: NativeSocket::new(libc::NETLINK_NETFILTER as _)?,
            })
        })();
        if namespace.is_some()
            && unsafe { libc::setns(original.as_raw_fd(), libc::CLONE_NEWNET) } != 0
        {
            std::process::abort();
        }
        result
    }

    pub fn clear_flows(&mut self, ips: &[Ipv4Addr]) -> io::Result<()> {
        // Filtered DELETE scans the entire host table under a global mutex.
        // Dump once, then delete exact reply tuples with their conntrack IDs.
        let mut prof = super::vxlan::Profile::new("conntrack", 0);
        let entries = self.conntrack.dump(257, &[2, 0, 0, 0])?;
        prof.mark("dump");
        for entry in entries {
            if let Some(body) = flow_deletion(&entry, ips)? {
                match self.conntrack.request(258, REQUEST, &body) {
                    Ok(_) => {}
                    Err(e) if e.raw_os_error() == Some(libc::ENOENT) => {}
                    Err(e) => return Err(e),
                }
            }
        }
        prof.mark("filter_delete");
        Ok(())
    }
}

fn flow_deletion(entry: &[u8], ips: &[Ipv4Addr]) -> io::Result<Option<Vec<u8>>> {
    let body = entry
        .get(4..)
        .ok_or_else(|| io::Error::other("Truncated conntrack entry"))?;
    if entry[0] != 2 {
        return Ok(None);
    }
    let fields = attrs(body)?;
    let mut matches = false;
    for (_, tuple) in fields.iter().filter(|(kind, _)| matches!(kind, 1 | 2)) {
        for (_, addresses) in attrs(tuple)?.into_iter().filter(|(kind, _)| *kind == 1) {
            for (kind, address) in attrs(addresses)? {
                if matches!(kind, 1 | 2) && ips.iter().any(|ip| address == ip.octets()) {
                    matches = true;
                }
            }
        }
    }
    if !matches {
        return Ok(None);
    }
    let field = |kind| {
        fields
            .iter()
            .find(|(k, _)| *k == kind)
            .map(|(_, value)| *value)
            .ok_or_else(|| io::Error::other("Conntrack entry lacks identity"))
    };
    let mut deletion = entry[..4].to_vec();
    deletion.extend(attr(2 | NESTED, field(2)?));
    deletion.extend(attr(12, field(12)?));
    if let Some((_, zone)) = fields.iter().find(|(kind, _)| *kind == 18) {
        deletion.extend(attr(18, zone));
    }
    Ok(Some(deletion))
}

pub(super) fn info(index: u32, up: bool) -> Vec<u8> {
    [
        vec![0; 4],
        index.to_ne_bytes().to_vec(),
        u32::from(up).to_ne_bytes().to_vec(),
        1u32.to_ne_bytes().to_vec(),
    ]
    .concat()
}

pub(super) fn configure(
    route: &mut NativeSocket,
    index: u32,
    up: bool,
    master: Option<u32>,
) -> io::Result<()> {
    let mut body = info(index, up);
    if let Some(master) = master {
        body.extend(attr(10, &master.to_ne_bytes()));
    }
    match route.request(19, REQUEST, &body) {
        Ok(_) => Ok(()),
        Err(e) if !up && e.raw_os_error() == Some(libc::ENODEV) => Ok(()),
        Err(e) => Err(e),
    }
}

pub(super) fn address(
    route: &mut NativeSocket,
    index: u32,
    ip: Ipv4Addr,
    prefix: u8,
    delete: bool,
) -> io::Result<()> {
    let body = [
        vec![2, prefix, 0, 0],
        index.to_ne_bytes().to_vec(),
        attr(1, &ip.octets()),
        attr(2, &ip.octets()),
    ]
    .concat();
    match route.request(
        if delete { 21 } else { 20 },
        if delete { REQUEST } else { CREATE },
        &body,
    ) {
        Ok(_) => Ok(()),
        Err(e) if delete && e.raw_os_error() == Some(libc::EADDRNOTAVAIL) => Ok(()),
        Err(e) => Err(e),
    }
}

pub(super) fn synchronize(route: &mut NativeSocket, name: &str, index: u32) -> io::Result<()> {
    let data = route.request(
        18,
        REQUEST,
        &[vec![0; 16], attr(3, format!("{name}\0").as_bytes())].concat(),
    )?;
    if data.get(4..8) != Some(index.to_ne_bytes().as_slice()) {
        return Err(io::Error::other("Prepared interface identity changed"));
    }
    Ok(())
}

pub(super) fn clear_neighbors(route: &mut NativeSocket, index: u32) -> io::Result<()> {
    let header = [vec![0; 12], attr(8, &index.to_ne_bytes())].concat();
    for entry in route.dump(30, &header)? {
        if entry.len() < 12 {
            return Err(io::Error::other("Truncated neighbor entry"));
        }
        if matches!(entry[0], 2 | 10) && entry[4..8] == index.to_ne_bytes() {
            match route.request(29, REQUEST, &entry) {
                Ok(_) => {}
                Err(e) if e.raw_os_error() == Some(libc::ENOENT) => {}
                Err(e) => return Err(e),
            }
        }
    }
    Ok(())
}

pub(super) fn idle(route: &mut NativeSocket, name: &str, index: u32) -> io::Result<()> {
    let data = route.request(
        18,
        REQUEST,
        &[vec![0; 16], attr(3, format!("{name}\0").as_bytes())].concat(),
    )?;
    if data.len() < 16
        || data[4..8] != index.to_ne_bytes()
        || u32::from_ne_bytes(data[8..12].try_into().unwrap()) & 1 != 0
        || attrs(&data[16..])?
            .iter()
            .any(|(kind, value)| *kind == 10 && *value != [0; 4])
    {
        return Err(io::Error::other("Prepared interface is not idle"));
    }
    Ok(())
}

pub(super) fn clear_addresses(route: &mut NativeSocket, index: u32) -> io::Result<()> {
    let header = [vec![0; 4], index.to_ne_bytes().to_vec()].concat();
    for entry in route.dump(22, &header)? {
        if entry.len() < 8 {
            return Err(io::Error::other("Truncated address entry"));
        }
        if entry[4..8] == index.to_ne_bytes() {
            match route.request(21, REQUEST, &entry) {
                Ok(_) => {}
                Err(e) if e.raw_os_error() == Some(libc::EADDRNOTAVAIL) => {}
                Err(e) => return Err(e),
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn flow_cleanup_matches_both_tuples_and_preserves_zone_and_identity() {
        let ips: Vec<Ipv4Addr> = (1..=4).map(|last| Ipv4Addr::new(192, 0, 2, last)).collect();
        let tuple = |a: Ipv4Addr, b: Ipv4Addr| {
            [
                attr(
                    1 | NESTED,
                    &[attr(1, &a.octets()), attr(2, &b.octets())].concat(),
                ),
                attr(2 | NESTED, &attr(1, &[6])),
            ]
            .concat()
        };
        let reply = tuple(ips[2], ips[3]);
        let entry = [
            vec![2, 0, 0, 0],
            attr(1 | NESTED, &tuple(ips[0], ips[1])),
            attr(2 | NESTED, &reply),
            attr(12, &123u32.to_be_bytes()),
            attr(18, &79u16.to_be_bytes()),
        ]
        .concat();
        let expected = [
            vec![2, 0, 0, 0],
            attr(2 | NESTED, &reply),
            attr(12, &123u32.to_be_bytes()),
            attr(18, &79u16.to_be_bytes()),
        ]
        .concat();
        for ip in &ips {
            assert_eq!(
                flow_deletion(&entry, &[*ip]).unwrap(),
                Some(expected.clone())
            );
        }
        assert!(
            flow_deletion(&entry, &[Ipv4Addr::LOCALHOST])
                .unwrap()
                .is_none()
        );
    }
}
