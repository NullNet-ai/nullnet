//! VXLAN endpoint lifecycle, with native namespace and encryption configuration.

use super::RtNetLinkHandle;
use super::netlink::{add_link_echo, get_link_by_name};
use super::prepared_io::{self, EndpointIo};
use crate::nfqueue::BridgeIpCache;
use ipnetwork::Ipv4Network;
use nullnet_liberror::{Error, ErrorHandler, Location, location};
use rtnetlink::packet_route::link::{InfoData, InfoVeth};
use rtnetlink::{Handle, LinkBridge, LinkUnspec, LinkVeth, LinkVxlan};
use std::collections::HashMap;
use std::net::Ipv4Addr;
use std::os::fd::AsRawFd;
use std::sync::{Arc, LazyLock, Mutex as StdMutex, PoisonError};
use tokio::process::Command;
use tokio::sync::{Mutex as AsyncMutex, OwnedMutexGuard, Semaphore};

/// Matches `vxlan-setup.sh`'s `OVERLAY_MTU` — see that script's comment for
/// how the 1080-byte ceiling was measured against this underlay.
const OVERLAY_MTU: u32 = 1080;

/// MACsec adds up to 32 bytes of overhead (SecTAG + ICV for GCM-AES-256); the
/// underlying veth gets the extra room so the macsec interface on top of it
/// can still carry a full `OVERLAY_MTU`-sized frame.
const MACSEC_VETH_MTU: u32 = OVERLAY_MTU + 32;

// Reserved link groups batch one tunnel side's deletion in a single RTNL
// operation. Net ids use 21 bits; the low bit distinguishes the two sides.
fn link_group(vxlan_id: u32, client_side: bool) -> u32 {
    0x4e00_0000 | (vxlan_id << 1) | u32::from(client_side)
}

#[derive(Clone, PartialEq, Eq)]
pub(crate) struct VxlanSetupParams {
    pub(crate) vxlan_id: u32,
    pub(crate) ns_name: String,
    pub(crate) ns_net: Ipv4Network,
    pub(crate) br_name: String,
    pub(crate) br_net: Ipv4Network,
    pub(crate) local_ip: Ipv4Addr,
    pub(crate) remote_ip: Ipv4Addr,
    pub(crate) key_hex: String,
    pub(crate) dstport: u16,
    pub(crate) encrypted: bool,
    pub(crate) docker_container: Option<String>,
}

#[derive(Clone)]
pub(crate) struct VxlanTeardownParams {
    pub(crate) vxlan_id: u32,
    pub(crate) ns_name: String,
}

#[derive(Clone)]
struct EndpointNames {
    root_veth: String,
    transport_s: String,
    transport_c: String,
    vxlan: String,
    macsec: String,
}

impl EndpointNames {
    fn new(id: u32, namespace: &str, client_side: bool) -> Self {
        let side = if client_side { "c" } else { "s" };
        Self {
            root_veth: format!("{namespace}-o"),
            transport_s: format!("veth-{id}-s"),
            transport_c: format!("veth-{id}-c"),
            vxlan: format!("nnv_{id}_{side}"),
            macsec: format!("macsec-{id}{side}"),
        }
    }
}

// Both halves share a lifecycle lock; preparation never opens forwarding.
static VXLAN_LOCKS: LazyLock<StdMutex<HashMap<u32, Arc<AsyncMutex<()>>>>> =
    LazyLock::new(|| StdMutex::new(HashMap::new()));
static LIFECYCLE_SLOTS: Semaphore = Semaphore::const_new(32);
static COMMAND_SLOTS: Semaphore = Semaphore::const_new(8);
static ENDPOINTS: LazyLock<StdMutex<HashMap<String, Arc<Endpoint>>>> =
    LazyLock::new(|| StdMutex::new(HashMap::new()));

struct Endpoint {
    params: VxlanSetupParams,
    namespace: Option<Arc<super::endpoint_namespace::EndpointNamespace>>,
    names: EndpointNames,
    bridge: u32,
    outer: Option<u32>,
    inner: Option<u32>,
    transport: u32,
    forwarding: u32,
    io: Arc<StdMutex<(EndpointIo, Option<EndpointIo>)>>,
    active: StdMutex<bool>,
}

async fn lock(id: u32) -> OwnedMutexGuard<()> {
    let entry = VXLAN_LOCKS
        .lock()
        .unwrap_or_else(PoisonError::into_inner)
        .entry(id)
        .or_insert_with(|| Arc::new(AsyncMutex::new(())))
        .clone();
    entry.lock_owned().await
}

pub(crate) async fn prepare(
    rtnetlink: &RtNetLinkHandle,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let guard = lock(params.vxlan_id).await;
    let permit = LIFECYCLE_SLOTS.acquire().await.unwrap();
    let rtnetlink = rtnetlink.clone();
    let params = params.clone();
    let cache = cache.clone();
    tokio::spawn(async move {
        let (_guard, _permit) = (guard, permit);
        let existing = ENDPOINTS.lock().unwrap().get(&params.ns_name).cloned();
        if let Some(endpoint) = existing {
            return validate(&endpoint, &params, &cache).await;
        }
        match prepare_locked(&rtnetlink.handle, &params, &cache).await {
            Ok(endpoint) => {
                ENDPOINTS
                    .lock()
                    .unwrap()
                    .insert(params.ns_name.clone(), Arc::new(endpoint));
                Ok(())
            }
            Err(error) => {
                destroy_links(&rtnetlink.handle, &params).await?;
                Err(error)
            }
        }
    })
    .await
    .handle_err(location!())?
}

async fn validate(
    endpoint: &Endpoint,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let mut placement = params.clone();
    placement.key_hex.clear();
    if placement != endpoint.params {
        return Err("Prepared endpoint placement changed").handle_err(location!());
    }
    if let Some(namespace) = &endpoint.namespace {
        namespace.validate().handle_err(location!())?;
        let current = cache
            .namespace(params.docker_container.as_ref().unwrap())
            .await
            .handle_err(location!())?;
        if !namespace.same_namespace(&current).handle_err(location!())? {
            return Err("Prepared endpoint belongs to an old container generation")
                .handle_err(location!());
        }
    }
    Ok(())
}

async fn prepare_locked(
    handle: &Handle,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<Endpoint, Error> {
    let client = params.br_name.ends_with("_c");
    let group = link_group(params.vxlan_id, client);
    let names = EndpointNames::new(params.vxlan_id, &params.ns_name, client);
    let namespace = match &params.docker_container {
        Some(container) => Some(cache.namespace(container).await.handle_err(location!())?),
        None => None,
    };
    let bridge = add_link_echo(
        handle,
        LinkBridge::new(&params.br_name)
            .mtu(OVERLAY_MTU)
            .link_group(group)
            .down()
            .build(),
    )
    .await
    .handle_err(location!())?
    .header
    .index;
    let (outer, inner) = if let Some(namespace) = &namespace {
        namespace.validate().handle_err(location!())?;
        let inner_name = format!("{}-in", params.ns_name);
        let peer = LinkUnspec::new_with_name(&inner_name)
            .mtu(OVERLAY_MTU)
            .link_group(group)
            .setns_by_fd(namespace.file.as_raw_fd())
            .build();
        let outer = add_link_echo(
            handle,
            LinkVeth::new(&names.root_veth, &inner_name)
                .mtu(OVERLAY_MTU)
                .link_group(group)
                .set_info_data(InfoData::Veth(InfoVeth::Peer(peer)))
                .build(),
        )
        .await
        .handle_err(location!())?
        .header
        .index;
        let inner = get_link_by_name(&namespace.handle, &inner_name)
            .await?
            .header
            .index;
        (Some(outer), Some(inner))
    } else {
        (None, None)
    };
    let (transport, forwarding) = if params.local_ip == params.remote_ip {
        let result = handle
            .link()
            .add(
                LinkVeth::new(&names.transport_s, &names.transport_c)
                    .mtu(MACSEC_VETH_MTU)
                    .address(veth_mac(params.vxlan_id, 1))
                    .link_group(link_group(params.vxlan_id, false))
                    .set_info_data(InfoData::Veth(InfoVeth::Peer(
                        LinkUnspec::new_with_name(&names.transport_c)
                            .mtu(MACSEC_VETH_MTU)
                            .address(veth_mac(params.vxlan_id, 2))
                            .link_group(link_group(params.vxlan_id, true))
                            .build(),
                    )))
                    .build(),
            )
            .execute()
            .await;
        if let Err(error) = result {
            if !is_eexist(&error) {
                return Err(error).handle_err(location!());
            }
            let known = ENDPOINTS.lock().unwrap().values().any(|e| {
                e.params.vxlan_id == params.vxlan_id && e.params.local_ip == e.params.remote_ip
            });
            if !known {
                return Err("Refusing an unowned existing transport pair").handle_err(location!());
            }
        }
        let name = if client {
            &names.transport_c
        } else {
            &names.transport_s
        };
        let transport = get_link_by_name(handle, name).await?.header.index;
        let forwarding = if params.encrypted {
            super::native_macsec::prepare(
                names.macsec.clone(),
                transport,
                veth_mac(params.vxlan_id, if client { 1 } else { 2 }),
                group,
            )
            .await
            .handle_err(location!())?
        } else {
            transport
        };
        (transport, forwarding)
    } else {
        if params.encrypted && params.dstport != super::native_xfrm::PORT {
            return Err("Encrypted VXLAN requires the reserved shared port")
                .handle_err(location!());
        }
        let transport = add_link_echo(
            handle,
            LinkVxlan::new(&names.vxlan, params.vxlan_id)
                .mtu(OVERLAY_MTU)
                .link_group(group)
                .local(params.local_ip)
                .remote(params.remote_ip)
                .port(params.dstport)
                .build(),
        )
        .await
        .handle_err(location!())?
        .header
        .index;
        if params.encrypted {
            super::native_xfrm::prepare(transport, params.vxlan_id)
                .await
                .handle_err(location!())?;
        }
        (transport, transport)
    };
    let target = namespace.clone();
    let io = super::native_netlink::blocking(move || {
        let mut root = EndpointIo::open(None)?;
        let inner_io = target
            .as_ref()
            .map(|ns| EndpointIo::open(Some(&ns.file)))
            .transpose()?;
        root.route.request(
            19,
            super::native_netlink::REQUEST,
            &[
                prepared_io::info(forwarding, false),
                super::native_netlink::attr(4, &OVERLAY_MTU.to_ne_bytes()),
            ]
            .concat(),
        )?;
        Ok((root, inner_io))
    })
    .await
    .handle_err(location!())?;
    let mut params = params.clone();
    params.key_hex.clear();
    Ok(Endpoint {
        params,
        namespace,
        names,
        bridge,
        outer,
        inner,
        transport,
        forwarding,
        io: Arc::new(StdMutex::new(io)),
        active: StdMutex::new(false),
    })
}

pub(crate) async fn setup(
    _rtnetlink: &RtNetLinkHandle,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let mut prof = Profile::new("setup_admission", params.vxlan_id);
    let guard = lock(params.vxlan_id).await;
    prof.mark("id_lock");
    let permit = LIFECYCLE_SLOTS.acquire().await.unwrap();
    prof.mark("lifecycle_slot");
    drop(prof);
    let params = params.clone();
    let cache = cache.clone();
    tokio::spawn(async move {
        let (_guard, _permit) = (guard, permit);
        if !super::vxlan_environment::ready() {
            return Err("VXLAN host policy is not ready").handle_err(location!());
        }
        let endpoint = ENDPOINTS
            .lock()
            .unwrap()
            .get(&params.ns_name)
            .cloned()
            .ok_or("VXLAN endpoint has not been prepared")
            .handle_err(location!())?;
        validate(&endpoint, &params, &cache).await?;
        if *endpoint.active.lock().unwrap() {
            return Err("Prepared endpoint is already leased").handle_err(location!());
        }
        // Record partial activation too; only acknowledged reset makes it reusable.
        *endpoint.active.lock().unwrap() = true;
        let result = activate(endpoint.clone(), &params).await;
        if let Err(error) = result {
            reset(endpoint).await?;
            return Err(error);
        }
        if let Some(container) = &params.docker_container {
            cache.add_overlay(&params.ns_name, params.ns_net.ip(), container);
        }
        Ok(())
    })
    .await
    .handle_err(location!())?
}

async fn activate(endpoint: Arc<Endpoint>, params: &VxlanSetupParams) -> Result<(), Error> {
    if params.encrypted {
        let key = decode_key(&params.key_hex)?;
        if params.local_ip == params.remote_ip {
            super::native_macsec::associations(
                endpoint.forwarding,
                veth_mac(
                    params.vxlan_id,
                    if params.br_name.ends_with("_c") { 1 } else { 2 },
                ),
                Some(key),
            )
            .await
            .handle_err(location!())?;
        } else {
            super::native_xfrm::install(params.vxlan_id, params.local_ip, params.remote_ip, key)
                .await
                .handle_err(location!())?;
        }
    }
    super::native_netlink::blocking(move || {
        let (root, target) = &mut *endpoint.io.lock().unwrap();
        let p = &endpoint.params;
        if let (Some(index), Some(target)) = (endpoint.inner, target) {
            prepared_io::address(
                &mut target.route,
                index,
                p.ns_net.ip(),
                p.ns_net.prefix(),
                false,
            )?;
            prepared_io::configure(&mut target.route, index, true, None)?;
        }
        prepared_io::address(
            &mut root.route,
            endpoint.bridge,
            p.br_net.ip(),
            p.br_net.prefix(),
            false,
        )?;
        if let Some(index) = endpoint.outer {
            prepared_io::configure(&mut root.route, index, true, Some(endpoint.bridge))?;
        }
        prepared_io::configure(
            &mut root.route,
            endpoint.forwarding,
            true,
            Some(endpoint.bridge),
        )?;
        prepared_io::configure(&mut root.route, endpoint.bridge, true, None)?;
        prepared_io::configure(&mut root.route, endpoint.transport, true, None)?;
        Ok(())
    })
    .await
    .handle_err(location!())
}

// Called after BOTH endpoint setups, before publishing any application readiness.
pub(crate) async fn ready(id: u32) -> Result<(), Error> {
    let _guard = lock(id).await;
    let endpoints: Vec<_> = ENDPOINTS
        .lock()
        .unwrap()
        .values()
        .filter(|e| e.params.vxlan_id == id)
        .cloned()
        .collect();
    if endpoints.is_empty() {
        return Err("Prepared slot is missing").handle_err(location!());
    }
    super::native_netlink::blocking(move || {
        for endpoint in &endpoints {
            if !*endpoint.active.lock().unwrap() {
                return Err(std::io::Error::other("Prepared slot is not active"));
            }
            if let Some(namespace) = &endpoint.namespace {
                namespace.validate()?;
            }
            let (root, _) = &mut *endpoint.io.lock().unwrap();
            let same = endpoint.params.local_ip == endpoint.params.remote_ip;
            let transport = if same {
                if endpoint.params.br_name.ends_with("_c") {
                    &endpoint.names.transport_c
                } else {
                    &endpoint.names.transport_s
                }
            } else {
                &endpoint.names.vxlan
            };
            prepared_io::synchronize(&mut root.route, transport, endpoint.transport)?;
        }
        for endpoint in &endpoints {
            let (root, target) = &mut *endpoint.io.lock().unwrap();
            if endpoint.forwarding != endpoint.transport {
                prepared_io::synchronize(
                    &mut root.route,
                    &endpoint.names.macsec,
                    endpoint.forwarding,
                )?;
            }
            if let Some(index) = endpoint.outer {
                prepared_io::synchronize(&mut root.route, &endpoint.names.root_veth, index)?;
            }
            prepared_io::synchronize(&mut root.route, &endpoint.params.br_name, endpoint.bridge)?;
            if let (Some(index), Some(target)) = (endpoint.inner, target) {
                prepared_io::synchronize(
                    &mut target.route,
                    &format!("{}-in", endpoint.params.ns_name),
                    index,
                )?;
            }
        }
        Ok(())
    })
    .await
    .handle_err(location!())
}

pub(crate) async fn teardown(
    _rtnetlink: &RtNetLinkHandle,
    params: &VxlanTeardownParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let mut prof = Profile::new("teardown_admission", params.vxlan_id);
    let guard = lock(params.vxlan_id).await;
    prof.mark("id_lock");
    let permit = LIFECYCLE_SLOTS.acquire().await.unwrap();
    prof.mark("lifecycle_slot");
    drop(prof);
    let endpoint = ENDPOINTS.lock().unwrap().get(&params.ns_name).cloned();
    let cache = cache.clone();
    let ns_name = params.ns_name.clone();
    tokio::spawn(async move {
        let (_guard, _permit) = (guard, permit);
        if let Some(endpoint) = endpoint {
            reset(endpoint.clone()).await?;
            if let Some(namespace) = &endpoint.namespace {
                namespace.validate().handle_err(location!())?;
            }
        }
        cache.remove_overlay(&ns_name);
        Ok(())
    })
    .await
    .handle_err(location!())?
}

async fn reset(endpoint: Arc<Endpoint>) -> Result<(), Error> {
    let mut total = Profile::new("reset", endpoint.params.vxlan_id);
    let mut links = Profile::new("reset_links", endpoint.params.vxlan_id);
    let e = endpoint.clone();
    super::native_netlink::blocking(move || {
        links.mark("blocking_wait");
        let (root, target) = &mut *e.io.lock().unwrap();
        links.mark("io_lock");
        prepared_io::configure(&mut root.route, e.transport, false, None)?;
        links.mark("transport_down");
        prepared_io::configure(&mut root.route, e.bridge, false, None)?;
        links.mark("bridge_down");
        prepared_io::configure(&mut root.route, e.forwarding, false, Some(0))?;
        links.mark("forwarding_detach");
        if let Some(index) = e.outer {
            prepared_io::configure(&mut root.route, index, false, Some(0))?;
        links.mark("outer_detach");
        }
        if let (Some(index), Some(target)) = (e.inner, target) {
            prepared_io::configure(&mut target.route, index, false, None)?;
        links.mark("inner_down");
        }
        Ok(())
    })
    .await
    .handle_err(location!())?;
    total.mark("links_phase");
    if endpoint.params.encrypted {
        if endpoint.params.local_ip == endpoint.params.remote_ip {
            super::native_macsec::associations(
                endpoint.forwarding,
                veth_mac(
                    endpoint.params.vxlan_id,
                    if endpoint.params.br_name.ends_with("_c") {
                        1
                    } else {
                        2
                    },
                ),
                None,
            )
            .await
            .handle_err(location!())?;
        } else {
            super::native_xfrm::remove(endpoint.params.vxlan_id)
                .await
                .handle_err(location!())?;
        }
    }
    total.mark("keys");
    let mut tail = Profile::new("reset_tail", endpoint.params.vxlan_id);
    let result = super::native_netlink::blocking(move || {
        tail.mark("blocking_wait");
        let (root, target) = &mut *endpoint.io.lock().unwrap();
        tail.mark("io_lock");
        let p = &endpoint.params;
        root.clear_flows(&[p.ns_net.ip(), p.br_net.ip()])?;
        tail.mark("root_conntrack");
        prepared_io::clear_neighbors(&mut root.route, endpoint.bridge)?;
        tail.mark("root_neighbors");
        prepared_io::clear_addresses(&mut root.route, endpoint.bridge)?;
        tail.mark("root_addresses");
        if let (Some(index), Some(target)) = (endpoint.inner, target) {
            target.clear_flows(&[p.ns_net.ip()])?;
        tail.mark("target_conntrack");
            prepared_io::clear_neighbors(&mut target.route, index)?;
        tail.mark("target_neighbors");
            prepared_io::clear_addresses(&mut target.route, index)?;
        tail.mark("target_addresses");
            prepared_io::idle(&mut target.route, &format!("{}-in", p.ns_name), index)?;
        tail.mark("target_verify");
        }
        let transport_name = if p.local_ip == p.remote_ip {
            if p.br_name.ends_with("_c") {
                &endpoint.names.transport_c
            } else {
                &endpoint.names.transport_s
            }
        } else {
            &endpoint.names.vxlan
        };
        prepared_io::idle(&mut root.route, transport_name, endpoint.transport)?;
        if endpoint.forwarding != endpoint.transport {
            prepared_io::idle(&mut root.route, &endpoint.names.macsec, endpoint.forwarding)?;
        }
        prepared_io::idle(&mut root.route, &p.br_name, endpoint.bridge)?;
        if let Some(index) = endpoint.outer {
            prepared_io::idle(&mut root.route, &endpoint.names.root_veth, index)?;
        }
        tail.mark("root_verify");
        *endpoint.active.lock().unwrap() = false;
        Ok(())
    })
    .await
    .handle_err(location!());
    total.mark("tail_phase");
    result
}

pub(crate) async fn destroy(
    rtnetlink: &RtNetLinkHandle,
    params: &VxlanTeardownParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let _guard = lock(params.vxlan_id).await;
    let endpoints: Vec<_> = ENDPOINTS
        .lock()
        .unwrap()
        .values()
        .filter(|e| e.params.vxlan_id == params.vxlan_id)
        .cloned()
        .collect();
    for endpoint in endpoints {
        destroy_endpoint(&rtnetlink.handle, endpoint.clone()).await?;
        cache.remove_overlay(&endpoint.params.ns_name);
    }
    Ok(())
}

pub(crate) async fn destroy_all(rtnetlink: &RtNetLinkHandle) -> Result<(), Error> {
    let endpoints: Vec<_> = ENDPOINTS.lock().unwrap().values().cloned().collect();
    for endpoint in endpoints {
        destroy_endpoint(&rtnetlink.handle, endpoint).await?;
    }
    Ok(())
}

async fn destroy_endpoint(handle: &Handle, endpoint: Arc<Endpoint>) -> Result<(), Error> {
    // Deletion closes forwarding even when a partially prepared device vanished.
    destroy_links(handle, &endpoint.params).await?;
    if endpoint.params.local_ip != endpoint.params.remote_ip {
        super::native_xfrm::remove(endpoint.params.vxlan_id)
            .await
            .handle_err(location!())?;
    }
    let e = endpoint.clone();
    super::native_netlink::blocking(move || {
        let (root, target) = &mut *e.io.lock().unwrap();
        root.clear_flows(&[e.params.ns_net.ip(), e.params.br_net.ip()])?;
        if let Some(target) = target {
            target.clear_flows(&[e.params.ns_net.ip()])?;
        }
        Ok(())
    })
    .await
    .handle_err(location!())?;
    ENDPOINTS.lock().unwrap().remove(&endpoint.params.ns_name);
    Ok(())
}

async fn destroy_links(handle: &Handle, params: &VxlanSetupParams) -> Result<(), Error> {
    use rtnetlink::packet_route::link::LinkAttribute;
    let mut request = handle.link().del(0);
    request
        .message_mut()
        .attributes
        .push(LinkAttribute::Group(link_group(
            params.vxlan_id,
            params.br_name.ends_with("_c"),
        )));
    match request.execute().await {
        Ok(()) => Ok(()),
        Err(rtnetlink::Error::NetlinkError(e))
            if e.code.map(std::num::NonZeroI32::get) == Some(-libc::ENODEV) =>
        {
            Ok(())
        }
        Err(e) => Err(e).handle_err(location!()),
    }
}

// helpers -----------------------------------------------------------------------------------------

// Commands may wait on Docker or the kernel; keep that work off runtime
// workers and cap child processes independently of the number of tunnel tasks.
#[cfg(test)]
async fn command_status(command: &mut Command) -> std::io::Result<std::process::ExitStatus> {
    let _permit = COMMAND_SLOTS
        .acquire()
        .await
        .expect("command admission stays open");
    command.kill_on_drop(true).status().await
}

pub(super) async fn command_output(command: &mut Command) -> std::io::Result<std::process::Output> {
    let _permit = COMMAND_SLOTS
        .acquire()
        .await
        .expect("command admission stays open");
    command.kill_on_drop(true).output().await
}

/// Whether `err` is the netlink `EEXIST` NACK — the raw rtnetlink error, not
/// yet converted to this crate's `Error` (which loses the code).
fn is_eexist(err: &rtnetlink::Error) -> bool {
    matches!(
        err,
        rtnetlink::Error::NetlinkError(e)
            if e.code.map(std::num::NonZeroI32::get) == Some(-libc::EEXIST)
    )
}

/// Derives a locally-administered MAC from the net id and side (1 = `_s`, 2 =
/// `_c`), so each side's SCI is a pure function of `vxlan_id`. Mirrors
/// `veth_mac()` in `vxlan-setup.sh`. 0x02 = locally administered.
fn veth_mac(vxlan_id: u32, side: u8) -> Vec<u8> {
    let id = vxlan_id.to_be_bytes();
    vec![0x02, side, id[0], id[1], id[2], id[3]]
}

#[cfg(test)]
fn format_mac(mac: &[u8]) -> String {
    mac.iter()
        .map(|b| format!("{b:02x}"))
        .collect::<Vec<_>>()
        .join(":")
}

#[cfg(test)]
mod tests {

    #[tokio::test]
    async fn command_wait_yields_and_preserves_output_and_status() {
        let mut command = tokio::process::Command::new("sleep");
        command.arg("2");
        tokio::select! {
            biased;
            _ = super::command_status(&mut command) => panic!("child wait blocked the runtime"),
            () = tokio::time::sleep(std::time::Duration::from_millis(20)) => {}
        }
        let out = super::command_output(
            tokio::process::Command::new("sh").args(["-c", "printf diagnostic; exit 7"]),
        )
        .await
        .unwrap();
        assert_eq!(out.stdout, b"diagnostic");
        assert_eq!(out.status.code(), Some(7));
    }

    use super::{format_mac, veth_mac};

    #[test]
    fn veth_mac_matches_vxlan_setup_shs_printf_derivation() {
        // veth_mac() $1=1 (( (100>>24)&0xff )) .. (100&0xff) -> 02:01:00:00:00:64
        assert_eq!(format_mac(&veth_mac(100, 1)), "02:01:00:00:00:64");
        assert_eq!(format_mac(&veth_mac(100, 2)), "02:02:00:00:00:64");
    }

    #[test]
    fn veth_mac_is_locally_administered_and_side_scoped() {
        let s = veth_mac(2_097_151, 1);
        let c = veth_mac(2_097_151, 2);
        assert_eq!(s[0], 0x02);
        assert_eq!(c[0], 0x02);
        assert_eq!(s[1], 1);
        assert_eq!(c[1], 2);
        assert_eq!(&s[2..], &c[2..], "both sides derive from the same net id");
    }
}

fn decode_key(hex: &str) -> Result<[u8; 32], Error> {
    if hex.len() != 64 {
        return Err("Invalid VXLAN encryption key length").handle_err(location!());
    }
    let mut key = [0; 32];
    for (index, byte) in key.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&hex[index * 2..index * 2 + 2], 16).handle_err(location!())?;
    }
    Ok(key)
}

#[cfg(test)]
#[path = "vxlan_kernel_tests.rs"]
mod kernel_tests;


pub(super) struct Profile {
    operation: &'static str,
    id: u32,
    last: std::time::Instant,
    stages: Vec<(&'static str, u128)>,
}
impl Profile {
    pub(super) fn new(operation: &'static str, id: u32) -> Self {
        Self { operation, id, last: std::time::Instant::now(), stages: Vec::new() }
    }
    pub(super) fn mark(&mut self, stage: &'static str) {
        self.stages.push((stage, self.last.elapsed().as_micros()));
        self.last = std::time::Instant::now();
    }
}
impl Drop for Profile {
    fn drop(&mut self) {
        use std::io::Write;
        let line = format!("\n[nnprofile] {} {} {:?}\n", self.operation, self.id, self.stages);
        let _ = std::io::stderr().write_all(line.as_bytes());
    }
}
