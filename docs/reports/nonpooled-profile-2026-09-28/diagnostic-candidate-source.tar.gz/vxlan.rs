//! VXLAN endpoint lifecycle, with native namespace and encryption configuration.

use super::RtNetLinkHandle;
use super::netlink::{add_link_echo, get_link_by_name, set_link_mtu_up};
use crate::nfqueue::BridgeIpCache;
use ipnetwork::Ipv4Network;
use nullnet_liberror::{Error, ErrorHandler, Location, location};
use rtnetlink::packet_route::link::{InfoData, InfoVeth, LinkMessage};
use rtnetlink::{Handle, LinkUnspec, LinkVeth, LinkVxlan};
use std::collections::{HashMap, HashSet};
use std::net::{IpAddr, Ipv4Addr};
use std::os::fd::AsRawFd;
use std::sync::{Arc, LazyLock, Mutex as StdMutex, PoisonError};
use tokio::process::Command;
use tokio::sync::{Mutex as AsyncMutex, OwnedMutexGuard, Semaphore};

/// Matches `vxlan-setup.sh`'s `OVERLAY_MTU` — see that script's comment for
/// how the 1080-byte ceiling was measured against this underlay.
const OVERLAY_MTU: u32 = 1080;

/// MACsec adds up to 32 bytes of overhead (SecTAG + ICV for GCM-AES-256); the
/// underlying veth gets the extra room so the macsec interface on top of it
/// can still carry a full `OVERLAY_MTU`-sized frame.
const MACSEC_VETH_MTU: u32 = OVERLAY_MTU + 32;

// Reserved link groups batch one tunnel side's deletion in a single RTNL
// operation. Net ids use 21 bits; the low bit distinguishes the two sides.
fn link_group(vxlan_id: u32, client_side: bool) -> u32 {
    0x4e00_0000 | (vxlan_id << 1) | u32::from(client_side)
}

#[derive(Clone, PartialEq, Eq)]
pub(crate) struct VxlanSetupParams {
    pub(crate) vxlan_id: u32,
    pub(crate) ns_name: String,
    pub(crate) ns_net: Ipv4Network,
    pub(crate) br_name: String,
    pub(crate) br_net: Ipv4Network,
    pub(crate) local_ip: Ipv4Addr,
    pub(crate) remote_ip: Ipv4Addr,
    pub(crate) key_hex: String,
    pub(crate) dstport: u16,
    pub(crate) encrypted: bool,
    pub(crate) docker_container: Option<String>,
}

#[derive(Clone)]
pub(crate) struct VxlanTeardownParams {
    pub(crate) vxlan_id: u32,
    pub(crate) ns_name: String,
    pub(crate) br_name: String,
}

struct EndpointNames {
    root_veth: String,
    transport_s: String,
    transport_c: String,
    vxlan: String,
    macsec: String,
}

impl EndpointNames {
    fn new(id: u32, namespace: &str, client_side: bool) -> Self {
        let side = if client_side { "c" } else { "s" };
        Self {
            root_veth: format!("{namespace}-o"),
            transport_s: format!("veth-{id}-s"),
            transport_c: format!("veth-{id}-c"),
            vxlan: format!("nnv_{id}_{side}"),
            macsec: format!("macsec-{id}{side}"),
        }
    }

    fn into_names(self) -> Vec<String> {
        vec![
            self.root_veth,
            self.transport_s,
            self.transport_c,
            self.vxlan,
            self.macsec,
        ]
    }
}

// Serialize both endpoint halves and retirement before allowing net-id reuse.
static VXLAN_LOCKS: LazyLock<StdMutex<HashMap<u32, Arc<AsyncMutex<()>>>>> =
    LazyLock::new(|| StdMutex::new(HashMap::new()));

static LIFECYCLE_SLOTS: Semaphore = Semaphore::const_new(32);
// Retirement queues whole batches; native I/O still shares the 32-worker cap.
static RETIREMENT_SLOTS: Semaphore = Semaphore::const_new(super::vxlan_cleanup::QUEUE_CAPACITY);
type ReadyEndpoint = (
    VxlanSetupParams,
    Option<Arc<super::endpoint_namespace::EndpointNamespace>>,
);
static READY: LazyLock<StdMutex<HashMap<String, ReadyEndpoint>>> =
    LazyLock::new(|| StdMutex::new(HashMap::new()));

static OWNED: LazyLock<StdMutex<HashSet<String>>> = LazyLock::new(|| StdMutex::new(HashSet::new()));

static COMMAND_SLOTS: Semaphore = Semaphore::const_new(8);

async fn lock(vxlan_id: u32) -> OwnedMutexGuard<()> {
    let entry = VXLAN_LOCKS
        .lock()
        .unwrap_or_else(PoisonError::into_inner)
        .entry(vxlan_id)
        .or_insert_with(|| Arc::new(AsyncMutex::new(())))
        .clone();
    entry.lock_owned().await
}

pub(crate) async fn setup(
    rtnetlink_handle: &RtNetLinkHandle,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let mut admission = Profile::new("setup_admission", params.vxlan_id);
    let guard = Arc::new(lock(params.vxlan_id).await);
    admission.mark("id_lock");
    let permit = LIFECYCLE_SLOTS
        .acquire()
        .await
        .expect("lifecycle admission stays open");
    admission.mark("worker_slot");
    drop(admission);
    let handle = rtnetlink_handle.clone();
    let params = params.clone();
    let cache = cache.clone();
    // Once admitted, retain the lock through completion even if the RPC is cancelled.
    tokio::spawn(async move {
        let _permit = permit;
        let _setup = super::vxlan_cleanup::track_setup();
        let previous = READY.lock().unwrap().get(&params.ns_name).cloned();
        if let Some((previous, namespace)) = previous {
            if previous != params {
                return Err("Endpoint is already active with different parameters")
                    .handle_err(location!());
            }
            if let Some(namespace) = namespace {
                namespace.validate().handle_err(location!())?;
                if let Some(container) = &params.docker_container {
                    let current = cache.namespace(container).await.handle_err(location!())?;
                    if !namespace.same_namespace(&current).handle_err(location!())? {
                        return Err("Endpoint belongs to a previous container generation")
                            .handle_err(location!());
                    }
                }
            }
            return Ok(());
        }
        if !OWNED.lock().unwrap().insert(params.ns_name.clone()) {
            return Err("Endpoint cleanup must finish before reuse").handle_err(location!());
        }
        if let Some(container) = &params.docker_container {
            cache.add_overlay(&params.ns_name, params.ns_net.ip(), container);
        }
        match setup_locked(&handle, &params, &cache).await {
            Ok(namespace) => {
                READY
                    .lock()
                    .unwrap()
                    .insert(params.ns_name.clone(), (params, namespace));
                Ok(())
            }
            Err(error) => {
                let teardown = VxlanTeardownParams {
                    vxlan_id: params.vxlan_id,
                    ns_name: params.ns_name,
                    br_name: params.br_name,
                };
                if let Err(cleanup) =
                    teardown_locked(&handle, &teardown, &cache, guard.clone()).await
                {
                    return Err(format!(
                        "{}; rollback failed: {}",
                        error.to_str(),
                        cleanup.to_str()
                    ))
                    .handle_err(location!());
                }
                Err(error)
            }
        }
    })
    .await
    .handle_err(location!())?
}

async fn setup_locked(
    rtnetlink_handle: &RtNetLinkHandle,
    params: &VxlanSetupParams,
    cache: &BridgeIpCache,
) -> Result<Option<Arc<super::endpoint_namespace::EndpointNamespace>>, Error> {
    if !super::vxlan_environment::ready() {
        return Err("VXLAN host policy is not ready").handle_err(location!());
    }
    let mut prof = Profile::new("setup", params.vxlan_id);
    let handle = &rtnetlink_handle.handle;

    let names = EndpointNames::new(
        params.vxlan_id,
        &params.ns_name,
        params.br_name.ends_with("_c"),
    );

    // Host processes already use the bridge IP; only containers need a veth.
    let namespace = match &params.docker_container {
        Some(container) => Some(cache.namespace(container).await.handle_err(location!())?),
        None => None,
    };
    prof.mark("namespace");
    let out_link = if let Some(namespace) = &namespace {
        namespace.validate().handle_err(location!())?;
        let out_link = create_endpoint_veth(handle, params, namespace, &names).await?;
        prof.mark("veth_create");
        configure_ns_in(params, &namespace.handle).await?;
        prof.mark("veth_config");
        Some(out_link)
    } else {
        None
    };

    let bridge_index = super::bridge_pool::lease(handle, &params.br_name)
        .await
        .handle_err(location!())?;
    prof.mark("bridge_lease");
    let br_link = LinkUnspec::new_with_index(bridge_index).build();
    handle
        .address()
        .add(
            br_link.header.index,
            IpAddr::V4(params.br_net.ip()),
            params.br_net.prefix(),
        )
        .execute()
        .await
        .handle_err(location!())?;
    set_link_mtu_up(handle, &br_link, OVERLAY_MTU).await?;

    // Attach the root-namespace end of the namespace veth to the bridge.
    if let Some(out_link) = &out_link {
        attach_and_size(handle, out_link, br_link.header.index, OVERLAY_MTU).await?;
    }

    prof.mark("bridge_config");
    if params.local_ip == params.remote_ip {
        setup_same_host(handle, params, br_link.header.index, &names).await?;
    } else {
        setup_cross_host(handle, params, br_link.header.index, &names).await?;
    }

    prof.mark("transport");
    if let Some(namespace) = &namespace {
        namespace.validate().handle_err(location!())?;
    }

    prof.mark("validate");
    Ok(namespace)
}

async fn create_endpoint_veth(
    handle: &Handle,
    params: &VxlanSetupParams,
    namespace: &super::endpoint_namespace::EndpointNamespace,
    names: &EndpointNames,
) -> Result<LinkMessage, Error> {
    let veth_in = format!("{}-in", params.ns_name);
    let peer = LinkUnspec::new_with_name(&veth_in)
        .mtu(OVERLAY_MTU)
        .setns_by_fd(namespace.file.as_raw_fd())
        .build();
    add_link_echo(
        handle,
        LinkVeth::new(&names.root_veth, &veth_in)
            .mtu(OVERLAY_MTU)
            .link_group(link_group(params.vxlan_id, params.br_name.ends_with("_c")))
            .set_info_data(InfoData::Veth(InfoVeth::Peer(peer)))
            .build(),
    )
    .await
    .handle_err(location!())
}

/// Same host: connect the two bridges with a veth pair instead of a VXLAN
/// tunnel — this traffic never leaves the host — optionally wrapped in
/// MACsec (802.1AE, AES-256-GCM) for defense-in-depth against another,
/// differently-privileged process on the same host reading the plaintext
/// veth/bridge traffic directly.
async fn setup_same_host(
    handle: &Handle,
    params: &VxlanSetupParams,
    br_index: u32,
    names: &EndpointNames,
) -> Result<(), Error> {
    let veth_s = &names.transport_s;
    let veth_c = &names.transport_c;
    // A macsec interface inherits its parent veth's MAC, so derive both ends
    // from the net id: each side's SCI — and the peer address the other side
    // keys its RX SA to — becomes a pure function of `vxlan_id`.
    let mac_s = veth_mac(params.vxlan_id, 1);
    let mac_c = veth_mac(params.vxlan_id, 2);

    // Both endpoint halves share this pair. The second setup reuses it.
    let create = handle
        .link()
        .add(
            LinkVeth::new(veth_s, veth_c)
                .address(mac_s.clone())
                .link_group(link_group(params.vxlan_id, false))
                // Set both MACs at creation so udev never sees a random peer
                // address and races us with MACAddressPolicy=persistent.
                .set_info_data(InfoData::Veth(InfoVeth::Peer(
                    LinkUnspec::new_with_name(veth_c)
                        .address(mac_c.clone())
                        .link_group(link_group(params.vxlan_id, true))
                        .build(),
                )))
                .build(),
        )
        .execute()
        .await;
    if let Err(e) = create
        && !is_eexist(&e)
    {
        return Err(e).handle_err(location!());
    }
    let link_s = get_link_by_name(handle, veth_s).await?;
    let link_c = get_link_by_name(handle, veth_c).await?;
    let (local_link, peer_mac) = if params.br_name.ends_with("_s") {
        (link_s, mac_c)
    } else {
        (link_c, mac_s)
    };

    if params.encrypted {
        set_link_mtu_up(handle, &local_link, MACSEC_VETH_MTU).await?;

        let macsec_if = names.macsec.clone();
        let key = decode_key(&params.key_hex)?;
        let macsec_index = super::native_macsec::install(
            macsec_if.clone(),
            local_link.header.index,
            peer_mac,
            key,
            link_group(params.vxlan_id, params.br_name.ends_with("_c")),
            params.vxlan_id,
        )
        .await
        .handle_err(location!())?;

        let macsec_link = LinkUnspec::new_with_index(macsec_index).build();
        attach_and_size(handle, &macsec_link, br_index, OVERLAY_MTU).await?;
    } else {
        // Encryption disabled: attach the veth straight to the bridge.
        attach_and_size(handle, &local_link, br_index, OVERLAY_MTU).await?;
    }

    Ok(())
}

/// Cross-host encryption shares a UDP port; authenticated marks bind each SA to its edge.
async fn setup_cross_host(
    handle: &Handle,
    params: &VxlanSetupParams,
    br_index: u32,
    names: &EndpointNames,
) -> Result<(), Error> {
    if params.encrypted && params.dstport != super::native_xfrm::PORT {
        return Err("Encrypted VXLAN requires the reserved shared port").handle_err(location!());
    }
    let vxlan_name = &names.vxlan;
    handle
        .link()
        .add(
            LinkVxlan::new(vxlan_name, params.vxlan_id)
                .link_group(link_group(params.vxlan_id, params.br_name.ends_with("_c")))
                .local(params.local_ip)
                .remote(params.remote_ip)
                .port(params.dstport)
                .build(),
        )
        .execute()
        .await
        .handle_err(location!())?;
    let vxlan_link = get_link_by_name(handle, vxlan_name).await?;
    if params.encrypted {
        super::native_xfrm::install(
            vxlan_link.header.index,
            params.vxlan_id,
            params.local_ip,
            params.remote_ip,
            decode_key(&params.key_hex)?,
        )
        .await
        .handle_err(location!())?;
    }
    attach_and_size(handle, &vxlan_link, br_index, OVERLAY_MTU).await?;

    Ok(())
}

pub(crate) async fn teardown(
    rtnetlink_handle: &RtNetLinkHandle,
    params: &VxlanTeardownParams,
    cache: &BridgeIpCache,
) -> Result<(), Error> {
    let mut admission = Profile::new("teardown_admission", params.vxlan_id);
    let guard = Arc::new(lock(params.vxlan_id).await);
    admission.mark("id_lock");
    let permit = RETIREMENT_SLOTS
        .acquire()
        .await
        .expect("lifecycle admission stays open");
    admission.mark("worker_slot");
    drop(admission);
    let handle = rtnetlink_handle.clone();
    let params = params.clone();
    let cache = cache.clone();
    tokio::spawn(async move {
        let _permit = permit;
        teardown_locked(&handle, &params, &cache, guard).await
    })
    .await
    .handle_err(location!())?
}

async fn teardown_locked(
    rtnetlink_handle: &RtNetLinkHandle,
    params: &VxlanTeardownParams,
    cache: &BridgeIpCache,
    guard: Arc<OwnedMutexGuard<()>>,
) -> Result<(), Error> {
    let mut prof = Profile::new("retire", params.vxlan_id);
    READY
        .lock()
        .unwrap()
        .retain(|_, (setup, _)| setup.vxlan_id != params.vxlan_id);
    let handle = &rtnetlink_handle.handle;

    super::native_xfrm::remove(params.vxlan_id)
        .await
        .handle_err(location!())?;

    prof.mark("xfrm_remove");
    // Parent deletion also removes veth peers and their MACsec children.
    // Side-specific groups preserve the other side's bridge until its cleanup.
    super::vxlan_cleanup::remove(
        handle,
        link_group(params.vxlan_id, params.br_name.ends_with("_c")),
        params.br_name.clone(),
        EndpointNames::new(
            params.vxlan_id,
            &params.ns_name,
            params.br_name.ends_with("_c"),
        )
        .into_names(),
        guard.clone(),
    )
    .await
    .handle_err(location!())?;

    prof.mark("cleanup_worker");
    cache.remove_overlay(&params.ns_name);

    super::endpoint_namespace::remove(&params.ns_name)
        .await
        .handle_err(location!())?;

    OWNED.lock().unwrap().remove(&params.ns_name);

    prof.mark("namespace_remove");
    Ok(())
}

// helpers -----------------------------------------------------------------------------------------

// Commands may wait on Docker or the kernel; keep that work off runtime
// workers and cap child processes independently of the number of tunnel tasks.
#[cfg(test)]
async fn command_status(command: &mut Command) -> std::io::Result<std::process::ExitStatus> {
    let _permit = COMMAND_SLOTS
        .acquire()
        .await
        .expect("command admission stays open");
    command.kill_on_drop(true).status().await
}

pub(super) async fn command_output(command: &mut Command) -> std::io::Result<std::process::Output> {
    let _permit = COMMAND_SLOTS
        .acquire()
        .await
        .expect("command admission stays open");
    command.kill_on_drop(true).output().await
}

/// Whether `err` is the netlink `EEXIST` NACK — the raw rtnetlink error, not
/// yet converted to this crate's `Error` (which loses the code).
fn is_eexist(err: &rtnetlink::Error) -> bool {
    matches!(
        err,
        rtnetlink::Error::NetlinkError(e)
            if e.code.map(std::num::NonZeroI32::get) == Some(-libc::EEXIST)
    )
}

/// Attach `link` to bridge `controller` and shrink/bring it up, in one
/// message.
async fn attach_and_size(
    handle: &Handle,
    link: &LinkMessage,
    controller: u32,
    mtu: u32,
) -> Result<(), Error> {
    handle
        .link()
        .set(
            LinkUnspec::new_with_index(link.header.index)
                .controller(controller)
                .mtu(mtu)
                .up()
                .build(),
        )
        .execute()
        .await
        .handle_err(location!())?;
    Ok(())
}

async fn configure_ns_in(params: &VxlanSetupParams, handle: &Handle) -> Result<(), Error> {
    let link = get_link_by_name(handle, &format!("{}-in", params.ns_name)).await?;
    handle
        .address()
        .add(
            link.header.index,
            IpAddr::V4(params.ns_net.ip()),
            params.ns_net.prefix(),
        )
        .execute()
        .await
        .handle_err(location!())?;
    set_link_mtu_up(handle, &link, OVERLAY_MTU).await?;
    Ok(())
}

/// Derives a locally-administered MAC from the net id and side (1 = `_s`, 2 =
/// `_c`), so each side's SCI is a pure function of `vxlan_id`. Mirrors
/// `veth_mac()` in `vxlan-setup.sh`. 0x02 = locally administered.
fn veth_mac(vxlan_id: u32, side: u8) -> Vec<u8> {
    let id = vxlan_id.to_be_bytes();
    vec![0x02, side, id[0], id[1], id[2], id[3]]
}

#[cfg(test)]
fn format_mac(mac: &[u8]) -> String {
    mac.iter()
        .map(|b| format!("{b:02x}"))
        .collect::<Vec<_>>()
        .join(":")
}

#[cfg(test)]
mod tests {

    #[tokio::test]
    async fn command_wait_yields_and_preserves_output_and_status() {
        let mut command = tokio::process::Command::new("sleep");
        command.arg("2");
        tokio::select! {
            biased;
            _ = super::command_status(&mut command) => panic!("child wait blocked the runtime"),
            () = tokio::time::sleep(std::time::Duration::from_millis(20)) => {}
        }
        let out = super::command_output(
            tokio::process::Command::new("sh").args(["-c", "printf diagnostic; exit 7"]),
        )
        .await
        .unwrap();
        assert_eq!(out.stdout, b"diagnostic");
        assert_eq!(out.status.code(), Some(7));
    }

    use super::{format_mac, veth_mac};

    #[test]
    fn veth_mac_matches_vxlan_setup_shs_printf_derivation() {
        // veth_mac() $1=1 (( (100>>24)&0xff )) .. (100&0xff) -> 02:01:00:00:00:64
        assert_eq!(format_mac(&veth_mac(100, 1)), "02:01:00:00:00:64");
        assert_eq!(format_mac(&veth_mac(100, 2)), "02:02:00:00:00:64");
    }

    #[test]
    fn veth_mac_is_locally_administered_and_side_scoped() {
        let s = veth_mac(2_097_151, 1);
        let c = veth_mac(2_097_151, 2);
        assert_eq!(s[0], 0x02);
        assert_eq!(c[0], 0x02);
        assert_eq!(s[1], 1);
        assert_eq!(c[1], 2);
        assert_eq!(&s[2..], &c[2..], "both sides derive from the same net id");
    }
}

fn decode_key(hex: &str) -> Result<[u8; 32], Error> {
    if hex.len() != 64 {
        return Err("Invalid VXLAN encryption key length").handle_err(location!());
    }
    let mut key = [0; 32];
    for (index, byte) in key.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&hex[index * 2..index * 2 + 2], 16).handle_err(location!())?;
    }
    Ok(key)
}

#[cfg(test)]
#[path = "vxlan_kernel_tests.rs"]
mod kernel_tests;


pub(super) struct Profile {
    operation: &'static str,
    id: u32,
    last: std::time::Instant,
    stages: Vec<(&'static str, u128)>,
}
impl Profile {
    pub(super) fn new(operation: &'static str, id: u32) -> Self {
        Self { operation, id, last: std::time::Instant::now(), stages: Vec::new() }
    }
    pub(super) fn mark(&mut self, stage: &'static str) {
        self.stages.push((stage, self.last.elapsed().as_micros()));
        self.last = std::time::Instant::now();
    }
}
impl Drop for Profile {
    fn drop(&mut self) {
        super::vxlan::profile_log(format_args!("[nnprofile] {} {} {:?}", self.operation, self.id, self.stages));
    }
}

pub(super) fn profile_log(args: std::fmt::Arguments<'_>) {
    use std::io::Write;
    let line = format!("\n{args}\n");
    let _ = std::io::stderr().write_all(line.as_bytes());
}
