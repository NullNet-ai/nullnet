//! Dedicated endpoint bridges, retained only after acknowledged reset.
use super::netlink::add_link_echo;
use aes_gcm::aead::Generate;
use futures::{StreamExt, TryStreamExt, stream};
use rtnetlink::packet_route::link::{InfoKind, LinkAttribute, LinkInfo, LinkMessage};
use rtnetlink::{Handle, LinkBridge, LinkUnspec};
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{LazyLock, Mutex};

const ALIAS: &str = "nullnet:vxlan-bridge:v1";
const GROUP: u32 = 0x4e60_0001;
static LIMIT: LazyLock<usize> = LazyLock::new(|| {
    std::env::var("VXLAN_BRIDGE_POOL_SIZE")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(1024)
});
static POOL: LazyLock<Mutex<Pool>> = LazyLock::new(|| Mutex::new(Pool::default()));

#[derive(Default)]
struct Pool {
    idle: VecDeque<u32>,
    leased: HashMap<String, u32>,
}

fn name(link: &LinkMessage) -> Option<&str> {
    link.attributes.iter().find_map(|a| match a {
        LinkAttribute::IfName(name) => Some(name.as_str()),
        _ => None,
    })
}

pub(super) fn owned(link: &LinkMessage) -> bool {
    let bridge = link.attributes.iter().any(|a| {
        matches!(a, LinkAttribute::LinkInfo(info)
        if info.iter().any(|i| matches!(i, LinkInfo::Kind(InfoKind::Bridge))))
    });
    bridge
        && (link.attributes.iter().any(|a| {
            matches!(a, LinkAttribute::IfAlias(alias) if alias == ALIAS)
                || matches!(a, LinkAttribute::Group(group) if *group == GROUP)
        }) || name(link)
            .and_then(|name| name.strip_prefix("br_"))
            .is_some_and(|suffix| {
                if !super::owned_endpoint_suffix(suffix) {
                    return false;
                }
                let (id, side) = suffix.rsplit_once('_').unwrap();
                let group =
                    0x4e00_0000 | (id.parse::<u32>().unwrap() << 1) | u32::from(side == "c");
                link.attributes
                    .iter()
                    .any(|a| matches!(a, LinkAttribute::Group(value) if *value == group))
            }))
}

async fn create(handle: &Handle, name: &str) -> Result<u32, String> {
    let mut mac: [u8; 6] = Generate::generate();
    mac[0] = (mac[0] & 0xfc) | 2;
    let mut message = LinkBridge::new(name)
        .down()
        .address(mac.to_vec())
        .link_group(GROUP)
        .build();
    message
        .attributes
        .push(LinkAttribute::IfAlias(ALIAS.into()));
    let link = add_link_echo(handle, message)
        .await
        .map_err(|e| e.to_string())?;
    Ok(link.header.index)
}

pub(super) async fn lease(handle: &Handle, name: &str) -> Result<u32, String> {
    if POOL.lock().unwrap().leased.contains_key(name) {
        return Err(format!("Bridge lease {name} has not been retired"));
    }
    let idle = POOL.lock().unwrap().idle.pop_front();
    let index = if let Some(index) = idle {
        if let Err(error) = handle
            .link()
            .set(LinkUnspec::new_with_index(index).name(name).build())
            .execute()
            .await
        {
            POOL.lock().unwrap().idle.push_front(index);
            return Err(error.to_string());
        }
        index
    } else {
        create(handle, name).await?
    };
    POOL.lock().unwrap().leased.insert(name.into(), index);
    Ok(index)
}

pub(super) async fn release(handle: &Handle, names: &[String]) -> Result<(), String> {
    let leases: Vec<_> = {
        let pool = POOL.lock().unwrap();
        names
            .iter()
            .filter_map(|name| pool.leased.get(name).map(|index| (name.clone(), *index)))
            .collect()
    };
    if leases.is_empty() {
        return Ok(());
    }
    let mut prof = super::vxlan::Profile::new("bridge_release", leases.len() as u32);
    let indices: HashSet<_> = leases.iter().map(|(_, index)| *index).collect();
    let mut resets = Vec::new();
    for (_, index) in &leases {
        let index = *index;
        let handle = handle.clone();
        resets.push(async move {
            let mut message = LinkUnspec::new_with_index(index)
                .down()
                .name(format!("nnb_{index}"))
                .link_group(GROUP)
                .build();
            message
                .attributes
                .push(LinkAttribute::IfAlias(ALIAS.into()));
            handle
                .link()
                .set(message)
                .execute()
                .await
                .map_err(|e| e.to_string())
        });
    }
    stream::iter(resets)
        .buffer_unordered(32)
        .try_collect::<Vec<_>>()
        .await?;
    prof.mark("disable_rename");
    let addresses: Vec<_> = handle
        .address()
        .get()
        .execute()
        .try_collect()
        .await
        .map_err(|e| e.to_string())?;
    let results = stream::iter(addresses.into_iter().filter(|address| indices.contains(&address.header.index)).map(|address| {
        handle.address().del(address).execute()
    })).buffer_unordered(32).collect::<Vec<_>>().await;
    for result in results {
        result.map_err(|e| e.to_string())?;
    }
    prof.mark("addresses");
    let neighbors: Vec<_> = handle
        .neighbours()
        .get()
        .execute()
        .try_collect()
        .await
        .map_err(|e| e.to_string())?;
    for neighbor in neighbors {
        if indices.contains(&neighbor.header.ifindex)
            && matches!(
                neighbor.header.family,
                rtnetlink::packet_route::AddressFamily::Inet
                    | rtnetlink::packet_route::AddressFamily::Inet6
            )
        {
            handle
                .neighbours()
                .del(neighbor)
                .execute()
                .await
                .map_err(|e| e.to_string())?;
        }
    }
    prof.mark("neighbors");
    for index in &indices {
        let links = super::native_netlink::link_inventory(Some(*index))
            .await
            .map_err(|e| e.to_string())?;
        if links.iter().any(|link| link.controller == Some(*index)) {
            return Err("Retired bridge still has attached ports".into());
        }
    }
    prof.mark("port_verify");
    let mut overflow = Vec::new();
    {
        let mut pool = POOL.lock().unwrap();
        for (name, index) in leases {
            pool.leased.remove(&name);
            if pool.idle.len() < *LIMIT {
                pool.idle.push_back(index);
            } else {
                pool.leased.insert(name.clone(), index);
                overflow.push((name, index));
            }
        }
    }
    for (name, index) in overflow {
        handle
            .link()
            .del(index)
            .execute()
            .await
            .map_err(|e| e.to_string())?;
        POOL.lock().unwrap().leased.remove(&name);
    }
    Ok(())
}

pub(super) async fn recover(handle: &Handle) -> Result<(), String> {
    let links: Vec<LinkMessage> = handle
        .link()
        .get()
        .execute()
        .try_collect()
        .await
        .map_err(|e| e.to_string())?;
    let bridges: Vec<_> = links.iter().filter(|link| owned(link)).collect();
    // Disable forwarding before removing transports or old encryption state.
    for link in &bridges {
        let mut mac: [u8; 6] = Generate::generate();
        mac[0] = (mac[0] & 0xfc) | 2;
        handle
            .link()
            .set(
                LinkUnspec::new_with_index(link.header.index)
                    .down()
                    .address(mac.to_vec())
                    .link_group(GROUP)
                    .build(),
            )
            .execute()
            .await
            .map_err(|e| e.to_string())?;
    }
    let mut request = handle.link().del(0);
    const RETIRING: u32 = 0x4e40_0000;
    request
        .message_mut()
        .attributes
        .push(LinkAttribute::Group(RETIRING));
    let mut found = false;
    for link in &links {
        if owned(link) {
            continue;
        }
        if name(link).is_some_and(super::owned_vxlan_link) {
            handle
                .link()
                .set(
                    LinkUnspec::new_with_index(link.header.index)
                        .link_group(RETIRING)
                        .build(),
                )
                .execute()
                .await
                .map_err(|e| e.to_string())?;
            found = true;
        }
    }
    if found {
        request.execute().await.map_err(|e| e.to_string())?;
    }
    let names: Vec<_> = bridges
        .iter()
        .filter_map(|link| name(link).map(String::from))
        .collect();
    {
        let mut pool = POOL.lock().unwrap();
        for link in bridges {
            if let Some(name) = name(link) {
                pool.leased.insert(name.into(), link.header.index);
            }
        }
    }
    release(handle, &names).await?;
    Ok(())
}

pub(crate) async fn warm(handle: &Handle) -> Result<(), String> {
    let available = POOL.lock().unwrap().idle.len();
    let created: Vec<_> = stream::iter(
        (available..*LIMIT)
            .map(|slot| async move { create(handle, &format!("nnb_init{slot}")).await }),
    )
    .buffer_unordered(32)
    .try_collect()
    .await?;
    POOL.lock().unwrap().idle.extend(created);
    println!(
        "[vxlan] recovered bridge pool: {} idle slots",
        POOL.lock().unwrap().idle.len()
    );
    Ok(())
}
