use futures::StreamExt;
use rtnetlink::packet_route::link::LinkAttribute;
use rtnetlink::{Handle, LinkUnspec};
use std::collections::HashSet;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};
use tokio::sync::{OwnedMutexGuard, mpsc, oneshot};

// A single worker owns this temporary group; only retiring links enter it.
const RETIRING_GROUP: u32 = 0x4e40_0000;
const DELETE_BATCH: usize = 256;
pub(super) const QUEUE_CAPACITY: usize = 1024;
static ACTIVE_SETUPS: AtomicUsize = AtomicUsize::new(0);
type Request = (
    u32,
    String,
    Vec<String>,
    Arc<OwnedMutexGuard<()>>,
    oneshot::Sender<Result<(), String>>,
    std::time::Instant,
);
static CLEANUP: OnceLock<mpsc::Sender<Request>> = OnceLock::new();

pub(super) struct SetupGuard;

pub(super) fn track_setup() -> SetupGuard {
    ACTIVE_SETUPS.fetch_add(1, Ordering::Relaxed);
    SetupGuard
}

impl Drop for SetupGuard {
    fn drop(&mut self) {
        ACTIVE_SETUPS.fetch_sub(1, Ordering::Relaxed);
    }
}

pub(super) async fn remove(
    handle: &Handle,
    group: u32,
    bridge: String,
    names: Vec<String>,
    guard: Arc<OwnedMutexGuard<()>>,
) -> Result<(), String> {
    let sender = CLEANUP.get_or_init(|| {
        let (sender, mut receiver) = mpsc::channel::<Request>(QUEUE_CAPACITY);
        let handle = handle.clone();
        tokio::spawn(async move {
            let mut batch = Vec::with_capacity(DELETE_BATCH);
            while let Some(first) = receiver.recv().await {
                batch.push(first);
                // Deletion holds RTNL. Yield between smaller batches while setup
                // is active; the counter is only a scheduling hint, never a lock.
                let limit = if ACTIVE_SETUPS.load(Ordering::Relaxed) == 0 {
                    DELETE_BATCH
                } else {
                    16
                };
                while batch.len() < limit {
                    match receiver.try_recv() {
                        Ok(request) => batch.push(request),
                        Err(_) => break,
                    }
                }
                let groups = batch.iter().map(|(group, _, _, _, _, _)| *group).collect();
                let names = batch
                    .iter()
                    .flat_map(|(_, _, names, _, _, _)| names.iter().cloned())
                    .collect();
                let began = std::time::Instant::now();
                let waits: Vec<_> = batch.iter().map(|r| r.5.elapsed().as_micros()).collect();
                let result = match remove_groups(&handle, groups, names).await {
                    Ok(()) => {
                        super::vxlan::profile_log(format_args!("[nnprofile] cleanup_delete {} {}", batch.len(), began.elapsed().as_micros()));
                        let reset = std::time::Instant::now();
                        let bridges: Vec<_> = batch
                            .iter()
                            .map(|(_, bridge, _, _, _, _)| bridge.clone())
                            .collect();
                        let result = super::bridge_pool::release(&handle, &bridges).await;
                        super::vxlan::profile_log(format_args!("[nnprofile] cleanup_bridge {} {}", batch.len(), reset.elapsed().as_micros()));
                        result
                    }
                    error => error,
                };
                super::vxlan::profile_log(format_args!("[nnprofile] cleanup_wait {:?}", waits));
                for (_, _, _, _guard, response, _) in batch.drain(..) {
                    let _ = response.send(result.clone());
                }
            }
        });
        sender
    });
    let (response, received) = oneshot::channel();
    sender
        .send((group, bridge, names, guard, response, std::time::Instant::now()))
        .await
        .map_err(|e| e.to_string())?;
    received.await.map_err(|e| e.to_string())?
}

async fn remove_groups(
    handle: &Handle,
    groups: HashSet<u32>,
    names: Vec<String>,
) -> Result<(), String> {
    if groups.len() == 1 {
        return delete_group(handle, *groups.iter().next().unwrap()).await;
    }
    let mut prof = super::vxlan::Profile::new("delete_batch", groups.len() as u32);
    let links = super::native_netlink::links_by_name(names)
        .await
        .map_err(|e| e.to_string())?;
    prof.mark("lookup");
    let results = futures::stream::iter(links.into_iter().filter(|link| groups.contains(&link.group)).map(|link| {
        let handle = handle.clone();
        async move {
            handle.link().set(LinkUnspec::new_with_index(link.index).link_group(RETIRING_GROUP).build()).execute().await
        }
    })).buffer_unordered(32).collect::<Vec<_>>().await;
    for result in results {
            if let Err(error) = result {
                // Finish both assigned and unassigned groups on partial failure.
                let mut cleanup = delete_group(handle, RETIRING_GROUP).await;
                for group in &groups {
                    if let Err(error) = delete_group(handle, *group).await {
                        cleanup = Err(error);
                    }
                }
                return cleanup.map_err(|cleanup| format!("{error}; cleanup: {cleanup}"));
            }
    }
    prof.mark("regroup");
    let result = delete_group(handle, RETIRING_GROUP).await;
    prof.mark("delete");
    result
}

async fn delete_group(handle: &Handle, group: u32) -> Result<(), String> {
    let mut request = handle.link().del(0);
    request
        .message_mut()
        .attributes
        .push(LinkAttribute::Group(group));
    match request.execute().await {
        Ok(()) => Ok(()),
        Err(rtnetlink::Error::NetlinkError(e))
            if e.code.map(std::num::NonZeroI32::get) == Some(-libc::ENODEV) =>
        {
            Ok(())
        }
        Err(error) => Err(error.to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn cancelled_setup_releases_its_scheduling_hint() {
        let first = track_setup();
        let (started, received) = oneshot::channel();
        let setup = tokio::spawn(async move {
            let _guard = track_setup();
            started.send(()).unwrap();
            std::future::pending::<()>().await;
        });
        received.await.unwrap();
        assert_eq!(ACTIVE_SETUPS.load(Ordering::Relaxed), 2);
        drop(first);
        assert_eq!(ACTIVE_SETUPS.load(Ordering::Relaxed), 1);
        setup.abort();
        assert!(setup.await.unwrap_err().is_cancelled());
        assert_eq!(ACTIVE_SETUPS.load(Ordering::Relaxed), 0);
    }
}
